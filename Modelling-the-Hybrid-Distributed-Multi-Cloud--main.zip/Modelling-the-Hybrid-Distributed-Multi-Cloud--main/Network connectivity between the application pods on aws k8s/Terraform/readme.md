# Code link to the network policy deployment files along with the application and the terraform code to provision the infrastructure and cluster:-

  https://github.ibm.com/hybrid-multi-cloud-architectures/kub_aws_terraform
