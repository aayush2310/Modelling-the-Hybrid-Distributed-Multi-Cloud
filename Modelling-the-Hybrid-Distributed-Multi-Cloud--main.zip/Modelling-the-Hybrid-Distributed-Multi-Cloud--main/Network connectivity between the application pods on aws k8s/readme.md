# Link to the application

—>https://github.com/instana/robot-shop 
 
 
1) Creating the AWS EKS using terraform 

      (i) Created the EKS / automated the EKS infrastructure using terraform 
      
      (ii) Developed k8s cluster  with network policy - make network policy yaml files containing ingress, egress and taints &tolerances 
         
 
 
2) Creating the AWS EKS manually and running the helm commands in the cloud shell 

        (i)Create the EKS cluster through console 
        
        (ii)In the cloud shell of the cluster git clone the robot-shop with network policy GitHub code and run the helm commands 
        
            git clone https://github.ibm.com/hybrid-multi-cloud-architectures/kub_aws_terraform 
            
            cd robot-shop/K8s/helm 
           
            kubectl delete namespace robot-shop 
            
            kubectl create namespace robot-shop 
            
            helm install robot-shop --namespace robot-shop . 
            
            kubectl port-forward deployment/web 8080 -n robot-shop  —address='0.0.0.0' 
