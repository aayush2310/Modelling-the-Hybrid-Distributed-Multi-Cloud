# Link to the application

—>https://github.com/instana/robot-shop 

There are two methods to accomplish this task:-

1) Created the IBM Cloud instance manually and git cloning the application in the cloudshell

      (i)Create the instance through console 
      
      (ii)Clone the git repo in the cloud shell of the instance 
 
2) Creating the IBM Cloud instance/infrastructure using terraform and cloning the application in the cloud shell

       (i)Created the instance / automated the infrastructure using terraform 
       
       (ii)Clone the git repo in the cloud shell of the IBM Cloud instance 
 
