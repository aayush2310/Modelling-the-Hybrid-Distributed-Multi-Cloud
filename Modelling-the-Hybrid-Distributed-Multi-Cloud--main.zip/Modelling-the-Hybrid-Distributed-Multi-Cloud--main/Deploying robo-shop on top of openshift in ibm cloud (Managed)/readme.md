# Openshift deployment on IBM Cloud 

Step1:-
Refering to this repo- https://github.com/terraform-ibm-modules/terraform-ibm-cluster , this repo gives an idea of how to provision a openshift cluster(vpc) on
ibm cloud.But, to provision the cluster, I need to manually create vpc and subnets through the ibm cloud console and provide the vpc id and subnet id(s) in the 
variables.tf file.So, my next step was to write a terraform code to deploy openshift on ibm cloud where I would be making the vpc and subnets through the terraform
and not through console. 

Moreover, this repo also provides an idea(and also the code) for classic openshift openshift deployment in single-zone,multi-zone,kubernetes on single-zone,
multi-zone,etc. 

Step2:-
https://github.ibm.com/aayushjha2310/openshift-cluster-on-ibmcloud This repo contains a basic code to automate openshift on ibmcloud, where the vpc and subnets were
created using the terraform and not via the console.This code is very basic as it contains only one subnet in a vpc named “lab_vpc”.We need to build upon this code
to create multiple subnets,security groups,etc as done for aws. 
              Steps:- 
              
             (I)write terraform for vpc resource named “lab_vpc”. 
             
             (II)In the us-south, write terraform for subnet named “lab_vpc_subnets” in the vpc “lab_vpc” 
             
             (III)Write terraform for the provider block 
             
             (IV)Write terraform for creating an openshift cluster inside the VPC using the module  
                 “vpc_openshift_module”, named the openshift cluster as “vpc-cluster”.Then I referenced 
                  the id of the provisioned vpc,added the worker pool flavor and added worker zones. 
                  This was done in “openshift_vpc_cluster.tf” 
                  
             (V)In the variables.tf file , provide “ibmcloud_api_key”, “iaas_classic_apikey” and 
                  “iaas_classic_username”. Apart from that region and pool_flavor was provided. 
                  
             (VI)”terraform init”-->”terraform plan”-->”terraform apply” 
             
            (VII)One security group named “craziness-cavalry-nearness-sneezing" has also been created. 
            
            (VII)The resources(vpc,subnets,cluster,etc) were deployed on the ibm cloud.(pics in the repo) 

Step-3:-

https://github.ibm.com/aayushjha2310/OpenShift-Cluster-on-IBM-cloud-using-Terraform This repo contains two things-(I)Terraform templates to create a single zone 
VPC, a Subnet, and a Public Gateway that can be used to underpin a RHOIC cluster (II)Terraform templates for building a single zone RHOIC cluster 

Steps:-(Terraform templates to create a single zone VPC) 

(i)In main.tf, write terraform for “ibm_resource_group” named “aayushopenshift” for the workload and set it as “Default”, then set “ibm cloud region” as “us-east”
and “ibmcloud_zone” as “2”.”ibmcloud_zone” is the preffered ibm cloud zone in the region to use for my infrastructure. 

(ii)Then in main.tf, write terraform for “ibm_is_vpc” and named that vpc as “aayushopenshift” and connected it with the resource group I declared earlier. 

(iii)Then in main.tf, write terraform for a “public gateway” , named it as “aayushopenhift”.Then connected this public gateway with the above resource group using 
the “id”, connected this public gateway with the above vpc using the “id” and associated the public gateway with our specified zone. 

(iv)Then write terraform for “ibm_is_subnet” named as “aayushopenshift”,connected it with the vpc, public gateway, resource group and zone. 


Steps:-(Terraform templates for building a single zone RHOIC cluster) 

(i)In “main.tf”, write terraform for making “ibm_resource_instance” called “cos_instance” and named it as “aayushopenshift”.Specified the “service” for the 
instance as “cloud-object-storage", and location as global.Connecting it with the resource group I created earlier using the “resource_group_id” attribute. 

(ii)Then in “main.tf”, write terraform for “ibm_container_vpc_cluster” named it as “aayushopenshift” (name of the RHOIC cluster), associated it with the vpc using 
the “vpc_id” attribute.Specified the “cluster_version”(Openshift Version for RHOIC cluster), “cluster_flavor”(worker flavor for RHOIC cluster),”worker_count”
(worker count per zone for RHOIC cluster which I specified 3 here).Associated the cluster to the resource group using “resource_group_id”.Then specified the 
“cos_instance_crn” using the “cos_instance” id.(In IBM Cloud, a COS (Cloud Object Storage) instance CRN (Cloud Resource Name) is a unique identifier for a specific 
instance of Cloud Object Storage. The CRN is used to reference and manage the COS instance within the IBM Cloud platform.) , Then associated it with the zones
which I specified earlier and associated the cluster with my subnet earlier created named “aayushopenshift” 

(iii)First doing ”terraform init”-->”terraform plan”-->”terraform apply” for the vpc folder(refer the git repo) 

(iv)Then doing ”terraform init”-->”terraform plan”-->”terraform apply” for the OpenShift-cluster folder(refer git repo)

(v) The resources(vpc,subnets,public gateway,cluster,etc) were deployed on the ibm cloud.(pics in the repo) 

References:-
https://github.com/redhat-gpst/terraform.ibmcloud.rhoic
