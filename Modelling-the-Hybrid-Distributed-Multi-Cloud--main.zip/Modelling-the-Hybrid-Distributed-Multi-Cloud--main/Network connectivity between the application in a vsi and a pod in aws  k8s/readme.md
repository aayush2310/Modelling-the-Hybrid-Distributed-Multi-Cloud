For case of k8s pod wants to communicate with vsi :- 

   1)If network connection between any two resources is allowed in VPC. (This may be due to default ACL ,Security Group)  ( by default-connection allowed )

     a) Then we will just use internal ip of VSI and put it in the k8s pod spec . 
    
   2)If we are deny by default settings for network connectivity (i.e. ACLs and SGs are not default and do not allow everything). Then we have to apply step-1 then follow below steps:- 
   
      a)	Then ACLs for the subnets in which Worker nodes and VSIs reside have to be updated with allow rule.
      
      b) 	Similarly of SGs 
 
 
For case of vsi wants to connect to communicate with k8s pod . 

      1)	Create a node port service for k8s pod. Then in vsi config use worker node ip with node port for k8s pod address. 
 
      2) 	Then do step 2 in 1st case, if required 
      
In AWS, instead of using NodePort, we will use an Elastic Load Balancer (ELB) or Application Load Balancer (ALB) to expose the application components running in the Kubernetes cluster to the application running in the Virtual Server Instance (VSI). The ELB or ALB will distribute the traffic to the individual Kubernetes Pods based on their health.

In this nodeport.yaml file:

We define a LoadBalancer type Service.

We specify the selector to target the desired Pods using their labels.

The service listens on port 80 and forwards traffic to the Pods' port 8080 (replace this with the actual listening port of your application inside the Pod).

The service.beta.kubernetes.io/aws-load-balancer-internal annotation is set to "false," which means that the ALB will be external and accessible from the internet.
Change this to "true" if you want an internal ALB.

Once you have created the nodeport.yaml file, you can apply it to your Kubernetes cluster using the kubectl command:

kubectl apply -f nodeport.yaml

Kubernetes will then create an AWS Application Load Balancer (ALB) and automatically configure it to distribute the incoming traffic to the Pods based on their health.

You can repeat the same process to expose multiple application components by creating separate Services with their respective labels and ports.

Remember to replace YOUR_POD_APP_LABEL and the port numbers accordingly. Also, make sure that your Kubernetes cluster is running in AWS, and you have the necessary permissions to create AWS resources like the Application Load Balancer.

The application running in the VSI can communicate with the individual components of the application in the Kubernetes cluster by making requests to the ALB's endpoint.



The communication between a Kubernetes Pod and a VSI (Virtual Server Instance) is a two-way process, and there are different approaches for each direction. Let's go through them:

# Kubernetes Pod wants to communicate with VSI:
In this scenario, the Kubernetes Pod, which is running within the Kubernetes cluster, wants to initiate communication with a VSI outside the cluster.
For the Kubernetes Pod to communicate with the VSI, you typically need to expose the VSI's services to the outside world using a public IP address or domain name. This can be achieved by setting up an external load balancer or an Ingress resource in Kubernetes.

The YAML file for the Service in this case might look something like this:

```
apiVersion: v1
kind: Service
metadata:
  name: vsi-service
spec:
  type: LoadBalancer
  selector:
    app: YOUR_VSI_APP_LABEL
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080
```

In this example, you would replace YOUR_VSI_APP_LABEL with the label of your VSI application, and the service will expose the VSI application on port 8080. The external load balancer (AWS ELB or ALB) will be created automatically when you apply this YAML, and it will have a public IP or domain name that the Kubernetes Pod can use to communicate with the VSI.

# VSI wants to communicate with Kubernetes Pod:

In this scenario, the VSI running outside the Kubernetes cluster wants to initiate communication with a Kubernetes Pod running inside the cluster.
To enable the VSI to communicate with the Kubernetes Pod, you can use a NodePort or a LoadBalancer type service in Kubernetes, similar to the ones defined in the previous YAML file. The main difference is that for the LoadBalancer type, you would typically use cloud provider-specific annotations to configure the load balancer (like AWS ELB or ALB) to route traffic to the Kubernetes nodes where the Pods are running.

The YAML file for the Service in this case might look something like this:

```
apiVersion: v1
kind: Service
metadata:
  name: k8s-pod-service
spec:
  type: LoadBalancer
  selector:
    app: YOUR_K8S_POD_APP_LABEL
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-internal: "false" # Set to "true" if you want an internal ELB
```

In this example, you would replace YOUR_K8S_POD_APP_LABEL with the label of your Kubernetes Pod application, and the service will expose the Pod on port 8080. The AWS ELB or ALB will route traffic to the Kubernetes nodes where the Pods with the specified label are running, enabling communication from the VSI to the Kubernetes Pod.

Keep in mind that for security reasons, you might need to adjust network security settings, such as firewall rules or network policies, to allow communication between the VSI and the Kubernetes Pod. Also, consider using SSL/TLS encryption for secure communication between the VSI and the Kubernetes Pod.

# EXAMPLE

To enable communication between the Kubernetes Pods running in AWS and the application component "rabbit-mq" running in the VSI (Virtual Server Instance) in AWS, we need to use a NodePort Service for the "rabbit-mq" component in Kubernetes.

Here's the nodeport.yaml file that you can use:
```
apiVersion: v1
kind: Service
metadata:
  name: cart-service
spec:
  type: NodePort
  selector:
    app: cart
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: shipping-service
spec:
  type: NodePort
  selector:
    app: shipping
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: payment-service
spec:
  type: NodePort
  selector:
    app: payment
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: mongo-db-service
spec:
  type: NodePort
  selector:
    app: mongo-db
  ports:
    - name: http
      protocol: TCP
      port: 27017
      targetPort: 27017

---

apiVersion: v1
kind: Service
metadata:
  name: mysql-service
spec:
  type: NodePort
  selector:
    app: mysql
  ports:
    - name: http
      protocol: TCP
      port: 3306
      targetPort: 3306

---

apiVersion: v1
kind: Service
metadata:
  name: dispatch-service
spec:
  type: NodePort
  selector:
    app: dispatch
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: rabbit-mq-service
spec:
  type: LoadBalancer
  selector:
    app: rabbit-mq
  ports:
    - name: amqp
      protocol: TCP
      port: 5672
      targetPort: 5672
    - name: management
      protocol: TCP
      port: 15672
      targetPort: 15672
```
In this nodeport.yaml file, we define a separate NodePort Service for each application component in the Kubernetes cluster (cart, shipping, payment, mongo-db, mysql, and dispatch). These services will expose the respective application components on specific ports (e.g., port 80 for HTTP).

Additionally, we define a LoadBalancer type Service for the rabbit-mq application component running in the VSI. This service will expose the rabbit-mq component on ports 5672 and 15672 for AMQP and management access, respectively. We use the LoadBalancer type here since we want to expose the VSI component to the external world with a public IP provided by AWS Elastic Load Balancer (ELB) or Application Load Balancer (ALB).

After applying this nodeport.yaml file to your Kubernetes cluster using the kubectl apply -f nodeport.yaml command, you will have NodePort services for the application components in AWS Kubernetes and a LoadBalancer service for the rabbit-mq component running in the VSI. The Kubernetes pods can communicate with the rabbit-mq component in the VSI using the LoadBalancer service's public IP or domain name provided by AWS.
