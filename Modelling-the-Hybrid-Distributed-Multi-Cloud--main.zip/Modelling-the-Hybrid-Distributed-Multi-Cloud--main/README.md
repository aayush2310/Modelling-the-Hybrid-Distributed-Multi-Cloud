# Modelling-the-Hybrid-Distributed-Multi-Cloud-
Intern-Aayush Jha , Mentors=> ARUN KUMAR , Dasari Surya Sai Venkatesh , Pratibha Moogi

# AIM
* The aim is to abstract out the infrastructure 
requirements like CPU , GPU, RAM, TPU , NUMBER OF 
CLUSTERS, etc. from the  model specific information like 
Model Parameters/features, workload scale , Tech Stacks 
used , etc. which the AI Engineer/Software Developer 
provides so that we can create an architecture of the 
platform to deploy the workload on multi cloud services 
like AWS, IBM Cloud,GCP , Redhat Openshift,Azure,etc.

* The goal is to reduce the workload of Software 
Developers and Data Scientists so that they can focus on 
the application specific logics rather than specifying the 
deployment specific tasks like VPC, Subnets, Gateways 
and their interconnections on multi cloud services

# BACKGROUND

* At present , Applications can be deployed on multi cloud
services through infrastructure as code tool Terraform
on the cloud instances and Kubernetes Service of the
respective cloud.

* Also, network connection can be established between a
pod present in a Kubernetes cluster of a cloud service
provider and a pod running in a cluster which is
deployed on an external VSI.

* Moreover, an application can be deployed on top of
unmanaged Openshift in AWS and managed Openshift in
IBM Cloud

# CURRENT APPROACH

* Manual mapping of requirements and specifications to IBM Cloud Reference Architecture which is then deployed using infrastructure as code framework.

* The current approach is that the software developers 
and Data Scientists provide the infrastructure 
requirements for their projects and the network layer 
configurations like VPC , subnets, gateways, etc. which 
are not the business logic for them.

* Kubernetes cluster needs an underlying infra like IBM 
cloud or multi-cloud . The app and underlying infra 
needs logging and monitoring, app needs security .A 
lot of things need to be set up to run the app properly A
which requires a lot of tools and technologies which 
are non-functional requirements for a developer

# Limitations to the Current Approach

* Lack of generalization & using different methods to deploy models 
on different cloud platforms lead to, process being cumbersome.

* Sometimes, building infrastructure and maintaining it is more 
challenging than the actual business logic of the application 
development

* It needs an expertise of so many things within a single team

* It is hard to scale as each team will have hard time setting up the 
infra before they can release them to the end users

* If each team uses different tech stacks with different configs, it will 
cause inconsistency across organizations

# Methadology
```
1)Requirement Gathering
2)Cloud Provider Selection
3)Architecture Design
4)Cloud Resource Provisioning 
5)Data Management
6)Application Deployment and Migration
7)Security and Compliance
```

# EXPERIMENTS AND RESULTS

The following work has been accomplished in this order -

1. Deployed Robo-Shop on aws EC2 instance [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Deploying%20the%20Instana%20Robot-Shop%20Application%20on%20AWS%20EC2%20Instance) 
2. Deployed Robo-Shop on IBM Cloud  instance [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Deploying%20Instana%20Robo-Shop%20on%20IBM%20instance) 
3. Deployed Robot-Shop app on K8s AWS [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Deploying%20the%20Instant%20Robo-shop%20Application%20on%20Kubernetes%20AWS%20(EKS)) 
4. Deployed Robot-Shop app on K8s IBM Cloud [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Deploying%20the%20Instana%20Robo%20Shop%20application%20on%20IKS%20IBM%20Cloud) 
5. Network connectivity between the application pods on aws k8s [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Network%20connectivity%20between%20the%20application%20pods%20on%20aws%20k8s) 
6. Network connectivity between the application pods on ibm cloud k8s [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Network%20connectivity%20between%20the%20application%20pods%20on%20ibm%20cloud%20k8s) 
7. Network connectivity between the application in a vsi and a pod in aws  k8s [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Network%20connectivity%20between%20the%20application%20in%20a%20vsi%20and%20a%20pod%20in%20aws%20%20k8s) 
8. Network connectivity between the application in a vsi and a pod in ibm cloud [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Network%20connectivity%20between%20the%20application%20in%20a%20vsi%20and%20a%20pod%20in%20ibm%20cloud) 
9. Deploying robo-shop on top of openshift in aws(Unmanaged) [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Deploying%20robo-shop%20on%20top%20of%20openshift%20in%20aws%20(Unmanaged)) 
10. Deploying robo-shop on top of openshift in ibm cloud (Managed) [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Deploying%20robo-shop%20on%20top%20of%20openshift%20in%20ibm%20cloud%20(Managed)) 
11. LLM Deployment Differences and Requirement Gathering [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/LLM%20Deployment%20Differences%20and%20Requirement%20Gathering) 
12. Prerequisite for ROSA and IBM managed(RHOIC) (comparison)-->How we can fulfill the prerequisite? [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Prerequisite%20for%20ROSA%20and%20IBM%20managed(RHOIC)%20(comparison)--%3EHow%20we%20can%20fulfill%20the%20prerequisite%3F)
13. Deploying Kubeflow over the existing Kubernetes Cluster and then deploying the LLM project "Github Issue Summarization" on top of it. [link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/tree/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster) 
 
# FUTURE WORK

* Abstract language for describing (AI and Non-AI apps) paired with expert system which can infer infra from 
the requirements.
* Implementing Security and Compliance to protect data and application through proper encryption,  
monitoring , authentication and authorization.

# Presentation

![Link](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Aayush_Presentation.png)   
