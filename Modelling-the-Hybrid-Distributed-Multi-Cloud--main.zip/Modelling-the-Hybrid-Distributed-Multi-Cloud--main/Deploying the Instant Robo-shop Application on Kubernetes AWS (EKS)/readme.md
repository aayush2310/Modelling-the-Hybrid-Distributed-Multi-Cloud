The above task can be achieved in two ways:-

1)Creating the AWS EKS cluster manually through console and then running the helm commands in the cloud Shell to deploy the Instana Robot-Shop  on top of the EKS
  cluster.

2)Automating the AWS EKS cluster through IAC tool terraform and then running the helm commands in the cloud Shell to deploy the Instana Robot-Shop on top of the 
  EKS cluster.
  
# Instana Robot-Shop -

https://github.com/instana/robot-shop

# Helm Commands-

git clone https://github.com/instana/robot-shop.git

cd robot-shop/K8s/helm

kubectl delete namespace robot-shop

kubectl create namespace robot-shop

helm install robot-shop --namespace robot-shop .

kubectl port-forward deployment/web 8080 -n robot-shop  --address='0.0.0.0'


# Deploy helm through console
