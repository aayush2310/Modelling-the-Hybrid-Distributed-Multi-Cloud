# Steps:-

1) Configure the aws provider and specify the region.

2) Write the terraform script to create a vpc and assign a cidr block to it.

3) Create an internet gateway connected to the vpc exposing the vpc to the internet.

4) Create 4 subnets, two public and two private by assigning them the proper cidr block addresses (within the cidr block of the vpc) and availability zones.

5) Create a NAT gateway.By using NAT gateway, instances in a private subnet can connect to services outside your VPC but external services cannot initiate a connection with those instances.Also the creation of the NAT Gateway depends on the Internet Gateway which needs to created at first.Moreover, the NAT gateway is 
installed in one of the public subnets.

6) In the routes.tf, the nat gateway has been associated with the private subnets and the internet gateway has been associated with the public subnets.Thus the 
  network infrastructure (which is the bottom most layer) has been completed now.Lets now setup an EKS cluster on top of this network infra.
  
7) creating EKS cluster.Kubernetes clusters managed by Amazon EKS make calls to other AWS services on my behalf to manage the resources that iuse with the service.
  For eg, EKS will create an autoscaling group for each instance group if i use managed nodes.Before i can create Amazon EKS clusters,i must create an IAM role with 
  the AmazonEKSClusterPolicy.naming it terraform/6-eks.tf.
  
8) creating a single instance group for Kubernetes. Similar to the EKS cluster, it requires an IAM role as well.--in nodes.tf

9) To manage permissions for my applications that i deploy in Kubernetes.i can either attach policies to Kubernetes nodes directly.In that case, every pod will get 
  the same access to AWS resources.Or i can create OpenID connect provider, which will allow granting IAM permissions based on the service account used by the pod. 
  File name is terraform/8-iam-oidc.tf.
  
10) testing the provider first before deploying the autoscaller.It can save a lot of time.File name is terraform/9-iam-test.tf.

terraform apply

11) creating a pod to test IAM roles for service accounts.First, i am going to omit annotations to bind the service account with the role.The way it works,icreate a 
   service account and use it in my pod spec. It can be anything, deployment, statefulset, or some jobs. Giving it a name k8s/aws-test.yaml.
   
kubectl apply -f k8s/aws-test.yaml

kubectl exec aws-cli -- aws s3api list-buckets

12) adding missing annotation to the service account and redeploying the pod.--in k8s/aws-test.yaml.

kubectl delete -f k8s/aws-test.yaml
kubectl apply -f k8s/aws-test.yaml

kubectl exec aws-cli -- aws s3api list-buckets

13) deploying the sample application and exposing it using public & private load balancers.The 1st is a deployment object with a base nginx image.
   File--k8s/deployment.yaml.
   
14) To expose the application to the internet,i create a Kubernetes service of a type load balancer and use annotations to configure load balancer properties
   By default, Kubernetes will create a load balancer in public subnets, so i don't need to provide any additional configurations.Also, if i want a new network 
   load balancer instead of the old classic load balancer,i can add aws-load-balancer-type equal to nlb. file-- k8s/public-lb.yaml.
   
15) Creating both deployment & service objects.
    kubectl apply -f k8s/deployment.yaml
    kubectl apply -f k8s/public-lb.yaml

16) creating a private load balancer--if i have a large infrastructure with many different services,i have a requirement to expose the application only within my 
   VPC.To make it private,i need additional annotation: aws-load-balancer-internal and then provide the CIDR range.Usually,i use 0.0.0.0/0 to allow any services
   within my VPC to access it. Giving it a name k8s/private-lb.yaml.
   
   kubectl apply -f k8s/private-lb.yaml

17) EKS autoscaller-I will be using OpenID connect provider to create an IAM role and bind it with the autoscaller.creating an IAM policy and role first.It's 
   similar to the previous one,but autoscaller will be deployed in the kube-system namespace.File name-terraform/10-iam-autoscaler.tf
   
terraform apply

18) Creating cluster-autoscaler.yaml from "https://github.com/antonputra/tutorials/blob/main/lessons/102/k8s/cluster-autoscaler.yaml"-->source code for autoscaller

kubectl apply -f k8s/cluster-autoscaler.yaml

verifing that the autoscaler pod is up and running with the following command:-
kubectl get pods -n kube-system

checking logs for any error:-
kubectl logs -l app=cluster-autoscaler -n kube-system -f

# NOTE

//1) Why the roles neeed to be created?(in eks file)-ibm not present 

Creating an IAM Role and attaching the appropriate IAM policies is a necessary step when setting up an Amazon EKS cluster. The IAM Role is used by the EKS control plane to access and manage AWS resources on your behalf, such as creating and managing worker nodes, networking resources, and other AWS services. 
The aws_iam_role resource defines the IAM Role and its assume role policy, which specifies that the EKS control plane service (eks.amazonaws.com) is allowed to assume this role using the sts:AssumeRole action. This role is essential for the EKS control plane to authenticate itself and securely interact with your Kubernetes cluster. 
Without creating and attaching the IAM Role, the EKS control plane would not have the required permissions to operate your EKS cluster. Attempting to create the EKS cluster without the proper IAM Role will likely result in permission-related errors, and your EKS cluster may not function correctly.

//2)Why was oidc file required? 

OIDC (OpenID Connect) related resources are used to configure OIDC authentication for your Amazon EKS cluster. OIDC is an open standard for authentication that allows identity providers to authenticate users and obtain their information using JSON Web Tokens (JWT). 
The OIDC authentication mechanism is optional for Amazon EKS, but it provides several benefits: 
Simplified Identity Federation 
RBAC Integration 
Improved Security 
You can go ahead and provision an EKS cluster without enabling OIDC authentication. However, if you plan to use IAM roles for service accounts (IRSA) or utilize Kubernetes RBAC with IAM mapping, enabling OIDC is necessary. Without OIDC, you will have to use traditional IAM roles for authentication, which may be less flexible for certain use cases. 
 
