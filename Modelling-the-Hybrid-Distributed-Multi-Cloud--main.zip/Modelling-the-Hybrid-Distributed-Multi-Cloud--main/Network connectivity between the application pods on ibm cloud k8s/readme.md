Link to the application:-

—>https://github.com/instana/robot-shop 
 
 
1) Creating the IKS manually and running the helm commands in the cloud shell

        (i)Create the IKS cluster through console 
        
        (ii)In the cloud shell of the cluster git clone the robot-shop with network policy GitHub code and run the helm commands 
        
            git clone https://github.ibm.com/aayushjha2310/Robot-shop-master/tree/main 
            
            cd robot-shop/K8s/helm 
            
            kubectl delete namespace robot-shop
            
            kubectl create namespace robot-shop 
            
            helm install robot-shop --namespace robot-shop .
            
            kubectl port-forward deployment/web 8080 -n robot-shop  —address='0.0.0.0' 
 
 
2) Creating the IKS using terraform 

      (i)Created the IKS / automated the IKS infrastructure using terraform
      
      (ii)In the cloud shell of the cluster git clone the robot-shop and run the helm commands 
      
            git clone https://github.ibm.com/aayushjha2310/Robot-shop-master/tree/main 
            
            cd robot-shop/K8s/helm 
            
            kubectl delete namespace robot-shop 
            
            kubectl create namespace robot-shop 
            
            helm install robot-shop --namespace robot-shop .
            
            kubectl port-forward deployment/web 8080 -n robot-shop  —address=‘0.0.0.0' 
