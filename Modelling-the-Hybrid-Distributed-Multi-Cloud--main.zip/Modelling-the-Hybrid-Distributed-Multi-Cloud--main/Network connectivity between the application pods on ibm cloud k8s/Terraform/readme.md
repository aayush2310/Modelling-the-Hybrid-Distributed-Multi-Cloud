# Creating IKS through Terraform:-

 https://github.ibm.com/aayushjha2310/Creating-IKS-through-terraform 
 
# Code link to the network policy deployment files along with the application and the terraform code to provision the infrastructure and cluster:-

https://github.ibm.com/aayushjha2310/Robot-shop-master/tree/main 

# Docs:-

 https://suedbroecker.net/2022/07/05/use-terraform-to-create-a-vpc-and-a-kubernetes-cluster-on-ibm-cloud/ 
