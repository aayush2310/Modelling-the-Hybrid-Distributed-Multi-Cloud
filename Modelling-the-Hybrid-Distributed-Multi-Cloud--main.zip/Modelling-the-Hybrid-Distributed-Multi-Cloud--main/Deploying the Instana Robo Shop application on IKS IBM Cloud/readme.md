# Link to the Application:-
—>https://github.com/instana/robot-shop 

# There are two steps to accomplish this task:-

1)Creating the  IKS manually and running the helm commands in the cloud shell 

        (i)Create the IKS cluster through console 
        
        (ii)In the cloud shell of the cluster git clone the robot-shop and run the helm commands :-

            git clone https://github.com/instana/robot-shop.git  
            
            cd robot-shop/K8s/helm 
            
            kubectl delete namespace robot-shop 
            
            kubectl create namespace robot-shop 
            
            helm install robot-shop --namespace robot-shop . 
            
            kubectl port-forward deployment/web 8080 -n robot-shop  —address='0.0.0.0' 
 
            http://localhost:8080 
 
 
2)Creating the IKS using terraform 

      (i)Created the IKS / automated the IKS infrastructure using terraform  
      
      (ii)In the cloud shell of the cluster git clone the robot-shop and run the helm commands 
      
            git clone https://github.com/instana/robot-shop.git 
            
            cd robot-shop/K8s/helm 
            
            kubectl delete namespace robot-shop 
            
            kubectl create namespace robot-shop 
            
            helm install robot-shop --namespace robot-shop . 
            
            kubectl port-forward deployment/web 8080 -n robot-shop  —address=‘0.0.0.0' 
            
# Docs useful:-

Doc - https://suedbroecker.net/2022/07/05/use-terraform-to-create-a-vpc-and-a-kubernetes-cluster-on-ibm-cloud/ 

# Deploying Helm through Console


