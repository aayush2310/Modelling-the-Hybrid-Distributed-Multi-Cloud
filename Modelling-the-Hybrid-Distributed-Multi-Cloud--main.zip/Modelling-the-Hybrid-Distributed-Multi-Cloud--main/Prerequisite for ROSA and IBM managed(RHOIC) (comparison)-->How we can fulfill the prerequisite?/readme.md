
![Prereq. For rosa and ibm managed (comparison) ](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Prerequisite%20for%20ROSA%20and%20IBM%20managed(RHOIC)%20(comparison)--%3EHow%20we%20can%20fulfill%20the%20prerequisite%3F/Prereq.%20For%20rosa%20and%20ibm%20managed%20(comparison)%20.png)

# ROSA (MANAGED)
```
https://github.com/terraform-redhat/terraform-aws-rosa-sts 
```

# RHOIC (MANAGED)
```
https://github.com/redhat-gpst/terraform.ibmcloud.rhoic
```
