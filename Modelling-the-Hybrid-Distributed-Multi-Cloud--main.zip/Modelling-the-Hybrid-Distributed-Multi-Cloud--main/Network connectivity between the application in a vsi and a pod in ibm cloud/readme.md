For case of k8s pod wants to communicate with vsi :- 

   1)If network connection between any two resources is allowed in VPC. (This may be due to default ACL ,Security Group) (//by default-connection allowed )

     a) Then we will just use internal ip of VSI and put it in the k8s pod spec . 
    
   2)If we are deny by default settings for network connectivity (i.e. ACLs and SGs are not default and do not allow everything). Then we have to apply step-1 then follow below steps:- 
     
     a)	Then ACLs for the subnets in which Worker nodes and VSIs reside have to be updated with allow rule. 
     
     b) 	Similarly of SGs 
 
 
For case of vsi wants to connect to communicate with k8s pod . 
     
      1)	Create a node port service for k8s pod. Then in vsi config use worker node ip with node port for k8s pod address. 
 
      2) 	Then do step 2 in 1st case, if required 
      
# Nodeport.yaml file for the network connectivity between an application in a vsi and a pod in the Kubernetes cluster

To establish network connectivity between an application running in a Virtual Server Instance (VSI) and multiple components within a Kubernetes cluster, you can use Kubernetes Services with NodePort type.
In this nodeport.yaml file, we define three separate NodePort services, one for each component of the application. Make sure to replace placeholders like YOUR_POD_APP_LABEL_1, YOUR_POD_APP_LABEL_2, and YOUR_POD_APP_LABEL_3 with actual values that match your Kubernetes environment and deployments.

Each NodePort service exposes a different port on the Kubernetes Nodes (in this example, 30001, 30002, and 30003). The application running inside the VSI can communicate with these Kubernetes components using the corresponding NodePort and the Kubernetes Nodes' IP addresses.

Once you have created the nodeport.yaml file, you can apply it to your Kubernetes cluster using the kubectl command:

kubectl apply -f nodeport.yaml

Ensure that your VSI's firewall allows outbound traffic to the NodePorts on the Kubernetes Nodes and that the Kubernetes cluster allows inbound traffic on the NodePorts from the VSI. Additionally, ensure that the Pods for each component have the necessary network configurations to receive traffic from the VSI.

In IBM Cloud, the approach for enabling communication between a Kubernetes Pod and a VSI (Virtual Server Instance) is quite similar to what we discussed in case of aws, However, there are some differences in the way the services are exposed, specifically using the IBM Cloud Load Balancer service for external access.
Let's go through the YAML files for each direction of communication:
# Kubernetes Pod wants to communicate with VSI:
In this scenario, the Kubernetes Pod running within the IBM Cloud Kubernetes Service (IKS) cluster wants to initiate communication with a VSI outside the cluster.
To allow the Kubernetes Pod to communicate with the VSI, you can create a NodePort or a LoadBalancer type service in Kubernetes. However, instead of using annotations for cloud provider-specific load balancer settings (like AWS), you will use IBM Cloud-specific annotations to expose the service using the IBM Cloud Load Balancer service.
The YAML file for the Service in this case might look like this:
```
apiVersion: v1
kind: Service
metadata:
  name: vsi-service
  annotations:
    service.beta.kubernetes.io/ibm-load-balancer-cloud-provider-enable-features: "true"
spec:
  type: LoadBalancer
  selector:
    app: YOUR_VSI_APP_LABEL
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080
```
In this example, you would replace YOUR_VSI_APP_LABEL with the label of your VSI application. The service will expose the VSI application on port 8080 using the IBM Cloud Load Balancer service, which will provide a public IP or hostname that the Kubernetes Pod can use to communicate with the VSI.

# VSI wants to communicate with Kubernetes Pod:
In this scenario, the VSI running outside the IBM Cloud Kubernetes Service wants to initiate communication with a Kubernetes Pod running inside the cluster.
To enable the VSI to communicate with the Kubernetes Pod, you can use a NodePort or a LoadBalancer type service in Kubernetes, similar to the previous YAML file. However, once again, you will use IBM Cloud-specific annotations to expose the service using the IBM Cloud Load Balancer service.
The YAML file for the Service in this case might look like this:
```
apiVersion: v1
kind: Service
metadata:
  name: k8s-pod-service
  annotations:
    service.beta.kubernetes.io/ibm-load-balancer-cloud-provider-enable-features: "true"
spec:
  type: LoadBalancer
  selector:
    app: YOUR_K8S_POD_APP_LABEL
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080
```
In this example, you would replace YOUR_K8S_POD_APP_LABEL with the label of your Kubernetes Pod application. The service will expose the Pod on port 8080 using the IBM Cloud Load Balancer service, and the VSI can use the public IP or hostname provided by the load balancer to communicate with the Kubernetes Pod.

Keep in mind that the exact annotations and settings may vary depending on the specific version of the IBM Cloud Kubernetes Service and the Load Balancer service. Always refer to the official IBM Cloud documentation for the most up-to-date information on configuring network connectivity between IBM Cloud resources.

## EXAMPLE

To enable communication between the application component "rabbit-mq" running in the VSI and the other application components ("cart," "shipping," "payment," "mongo-db," "mysql," and "dispatch") running in the IBM Cloud Kubernetes Service (IKS) pods, we can use a NodePort Service in Kubernetes.

Here's the nodeport.yaml file that you can use:
```
apiVersion: v1
kind: Service
metadata:
  name: cart-service
spec:
  type: NodePort
  selector:
    app: cart
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: shipping-service
spec:
  type: NodePort
  selector:
    app: shipping
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: payment-service
spec:
  type: NodePort
  selector:
    app: payment
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: mongo-db-service
spec:
  type: NodePort
  selector:
    app: mongo-db
  ports:
    - name: http
      protocol: TCP
      port: 27017
      targetPort: 27017

---

apiVersion: v1
kind: Service
metadata:
  name: mysql-service
spec:
  type: NodePort
  selector:
    app: mysql
  ports:
    - name: http
      protocol: TCP
      port: 3306
      targetPort: 3306

---

apiVersion: v1
kind: Service
metadata:
  name: dispatch-service
spec:
  type: NodePort
  selector:
    app: dispatch
  ports:
    - name: http
      protocol: TCP
      port: 80
      targetPort: 8080

---

apiVersion: v1
kind: Service
metadata:
  name: rabbit-mq-service
spec:
  type: NodePort
  selector:
    app: rabbit-mq
  ports:
    - name: amqp
      protocol: TCP
      port: 5672
      targetPort: 5672
    - name: management
      protocol: TCP
      port: 15672
      targetPort: 15672
```
In this nodeport.yaml file, we define a separate NodePort Service for each application component in the Kubernetes cluster (cart, shipping, payment, mongo-db, mysql, and dispatch). These services will expose the respective application components on specific ports (e.g., port 80 for HTTP).

Additionally, we define a NodePort Service for the rabbit-mq application component running in the VSI. This service will expose the rabbit-mq component on ports 5672 and 15672 for AMQP and management access, respectively.

After applying this nodeport.yaml file to your Kubernetes cluster using the kubectl apply -f nodeport.yaml command, you will have a NodePort service for each component, allowing communication between the VSI and the Kubernetes pods in IBM Cloud. The VSI can communicate with the application components in the Kubernetes cluster using the NodePort service endpoints.
