# Openshift deployment on aws 

https://github.ibm.com/aayushjha2310/OpenShift_cluster_Terraform_AWS 

I had to create openshift bastion key using the command-( ssh-keygen -t rsa -b 4096 -C "bastion-key" ).The output of this command gave openshift bastion key. 

Again I created openshift nodes key using the command-(ssh-keygen -t rsa -b 4096 -C "node-key"). The output of this command gave openshift nodes key. 

saved these two keys in the same folder as my main.tf terraform file.  

Then used them in the variables.tf folder. Assigned these two key values in the respective variables section. 

Then in the variables.tf folder i used ami for the ec2 instance (aws) (Amazon Linux). I entered the ami value (string) in the respective variable. 

First a vpc was created (terraform code for vpc ), then one internet gateway attached to the vpc was created (terraform code for internet gateway ), 
then one public subnet  "OpenShift Public Subnet" was created(terraform code for public subnet) , and at last a route table ( terraform code for route table ) 
allowing all addresses access to the Internet gateway has been created (terraform code for it ). Finally associating the route table with the public subnet- giving 
all public subnet instances access to the internet. (terraform code for it ) 

Then create the internal DNS named "openshift.local" which is basically the OpenShift Cluster Internal DNS, associate it with the vpc "OpenShift VPC". 
(terraform code for it ) 

In the same file dns.tf, create Routes for 'master', 'node1' and 'node2'. (terraform code for it) 

Next about security groups, 3 security groups are created (terraform code for it)

(i)"OpenShift Internal VPC"=>This security group allows intra-node communication on all ports with all protocols which is basically the Default security group that allows all instances in the VPC to talk to each other over any port and protocol.  

(ii)OpenShift Public Ingress=>Security group that allows public ingress to instances, HTTP, HTTPS and more.  

(iii)OpenShift Public Egress=>Security group that allows egress to the internet for instances over HTTP and HTTPS. 

(iv)OpenShift SSH Access=>Security group that allows public ingress over SSH.  

Coming to aws key pair, 2 key pairs are made-(terraform code for it) 

(i)openshift_bastion and  

(ii)openshift_nodes.  

In the same file servers.tf, bastion user data script is created and then configuration for bastion is launched (i.e ec2 instance named "OpenShift Bastion" ). 
(terraform code for it) 

Then "master userdata script" is created (terraform code for it) and instance named "OpenShift Master" is launched.(On doing “terraform apply”) 

Then "node userdata script" is created (terraform code for it) and instance named "OpenShift Node 1" is launched (On doing “terraform apply”) and 
"OpenShift Node 2" is launched. (On doing “terraform apply”) 

Finally the terraform code written=>terraform init , terraform plan , terraform apply 

So total of 4 ec2 instances created when “terraform apply” runs successfully 

On running “terraform apply”, all the above mentioned resources were made. 
 
Original github repo of the code:- https://github.com/dwmkerr/terraform-aws-openshift  

# Docs- 

https://dwmkerr.com/get-up-and-running-with-openshift-on-aws/  

# AWS (Unmanaged)

Basically there are three steps which enable us to deploy an application on top of an openshift cluster in IBM Cloud.

1)Provision a network infrastructure by writing a terraform template to create a single zone VPC, a Subnet, and a Public Gateway that can be used to underpin an Openshift cluster.

2)Writing the terraform templates for building an openshift cluster.

3)Deploying an application of the infrastructure provisioned.

# Provision a network infrastructure by writing a terraform template to create a single zone VPC, a Subnet, and a Public Gateway that can be used to underpin an Openshift cluster and Writing the terraform templates for building an openshift cluster.

# Deploying an application of the infrastructure provisioned.

This task can be achieved in two ways:-

1) Deploying the application  using helm commands in the cloud console

2) Deploying the application using IAC tool Terraform.
   In the terraform code ( https://github.ibm.com/aayushjha2310/OpenShift_cluster_Terraform_AWS ), helm provider block has been used (main.tf).


 
 
 # Articles and Tutorials used as reference:- 
 
1) doc- https://ibm.github.io/multi-tenancy-documentation/automation/terraform/3-Provisionning-A-Kubernetes-Based-Infrastructure/ 

        https://github.com/cloud-native-toolkit/iascable 

2)Code used for trial & error - https://github.com/ibm-cloud-architecture/terraform-openshift4-aws

3)doc - https://registry.terraform.io/modules/literalice/openshift/aws/latest 

4)doc - https://docs.openshift.com/container-platform/4.13/installing/installing_aws/installing-aws-default.html  

5)doc - https://cloud.ibm.com/docs/vmwaresolutions?topic=vmwaresolutions-openshift-runbook-runbook-install-intro 

6)doc - https://registry.terraform.io/providers/terraform-redhat/ocm/latest/docs 

          https://github.com/terraform-redhat/terraform-provider-ocm  
 
