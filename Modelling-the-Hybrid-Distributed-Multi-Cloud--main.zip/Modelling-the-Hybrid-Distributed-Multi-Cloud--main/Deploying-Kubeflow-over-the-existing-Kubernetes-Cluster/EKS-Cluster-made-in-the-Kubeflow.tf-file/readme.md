![IMG-1](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/EKS-Cluster-made-in-the-Kubeflow.tf-file/Screenshot%201402-05-13%20at%2012.00.10.png) 

![IMG-2](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/EKS-Cluster-made-in-the-Kubeflow.tf-file/Screenshot%201402-05-13%20at%2014.52.24.png) 
