# Docs:-
```
1) https://aws.amazon.com/blogs/opensource/kubeflow-amazon-eks/

2) https://awslabs.github.io/kubeflow-manifests/docs/deployment/vanilla/guide-terraform/
```
