# Docs:-
```
1) https://aws.amazon.com/blogs/opensource/kubeflow-amazon-eks/

2) https://awslabs.github.io/kubeflow-manifests/docs/deployment/vanilla/guide-terraform/
```
![IMG-1](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/Kubeflow-1.png) 

![IMG-2](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/Kubeflow-2.png) 
# Connect kubeflow to an eks cluster

1)Define the "aws_eks_cluster_auth" data source:
```
data "aws_eks_cluster_auth" "kubeconfig" {
  name = aws_eks_cluster.your_cluster_name.name
}
```
Replace "your_cluster_name" with the actual name of your EKS cluster resource.

2)Create a kubeconfig file:
```
resource "local_file" "kubeconfig" {
  filename = "kubeconfig_${aws_eks_cluster.your_cluster_name.name}"
  content  = data.aws_eks_cluster_auth.kubeconfig.kubeconfig
}
```
This code will create a kubeconfig file named "kubeconfig_your_cluster_name" in the current working directory.

3)Set the KUBECONFIG environment variable:
```
locals {
  kubeconfig_path = "kubeconfig_${aws_eks_cluster.your_cluster_name.name}"
}

environment {
  variables = {
    KUBECONFIG = local.kubeconfig_path
  }
}
```
This will set the KUBECONFIG environment variable to point to the generated kubeconfig file.

4)Now, you can use the kubectl command or other Kubernetes clients to interact with the EKS cluster. For example:
```
resource "null_resource" "apply_kubeflow" {
  provisioner "local-exec" {
    command = "kubectl apply -f your_kubeflow_manifest.yaml"
  }
}
```
Replace "your_kubeflow_manifest.yaml" with the path to your Kubeflow manifest file. The null_resource with a local-exec provisioner is an example of how to apply your Kubeflow manifests to the EKS cluster using kubectl.

Remember to replace placeholders like "your_cluster_name" and "your_kubeflow_manifest.yaml" with the appropriate names and file paths according to your setup.

Note: Before executing this Terraform code, make sure you have the necessary AWS IAM permissions to access the EKS cluster and perform the required actions.

# Deploy the Kubeflow pipeline over a cluster on AWS EKS which is already deployed

```
provider "kubeflow" {
  # Replace with your EKS cluster endpoint URL
  eks_endpoint = "https://your-eks-cluster-endpoint"

  # Replace with the path to your kubeconfig file
  kubeconfig_path = "/path/to/your/kubeconfig"
}

resource "kubeflow_pipeline" "example_pipeline" {
  # Replace with the name you want to give to your Kubeflow pipeline
  name = "example-pipeline"

  # Replace with the path to your Kubeflow pipeline YAML file
  pipeline_yaml_path = "/path/to/your/pipeline.yaml"
}
```

# Kubeflow pipeline yaml file for the project GitHub issue summarization
```
apiVersion: argoproj.io/v1alpha1
kind: Workflow
metadata:
  name: github-issue-summarization
spec:
  entrypoint: main
  templates:
    - name: main
      steps:
        - - name: data-preprocessing
            template: data-preprocessing
          - name: train-model
            template: train-model
          - name: evaluate-model
            template: evaluate-model
    - name: data-preprocessing
      # Define data preprocessing component
      container:
        image: your-data-preprocessing-image
        # Specify input and output artifacts to access data
        inputs:
          artifacts:
            - name: raw-data
              path: /mnt/raw-data
        outputs:
          artifacts:
            - name: preprocessed-data
              path: /mnt/preprocessed-data
      # Define the command to run the data preprocessing script
      command: ["python", "data_preprocessing.py"]
      args: ["--input", "/mnt/raw-data", "--output", "/mnt/preprocessed-data"]

    - name: train-model
      # Define the training component
      container:
        image: your-train-model-image
        # Specify input artifacts, including preprocessed data and model configuration
        inputs:
          artifacts:
            - name: preprocessed-data
              path: /mnt/preprocessed-data
            - name: model-config
              path: /mnt/model-config
        outputs:
          artifacts:
            - name: trained-model
              path: /mnt/trained-model
      # Define the command to run the training script
      command: ["python", "train_model.py"]
      args: ["--data", "/mnt/preprocessed-data", "--config", "/mnt/model-config", "--output", "/mnt/trained-model"]

    - name: evaluate-model
      # Define the model evaluation component
      container:
        image: your-evaluate-model-image
        # Specify input artifacts, including test data and trained model
        inputs:
          artifacts:
            - name: test-data
              path: /mnt/test-data
            - name: trained-model
              path: /mnt/trained-model
      # Define the command to run the evaluation script
      command: ["python", "evaluate_model.py"]
      args: ["--data", "/mnt/test-data", "--model", "/mnt/trained-model"]
```

# To obtain the kubeconfig file for your Kubernetes cluster

1)Install and Configure AWS CLI

2)Install and Configure aws-iam-authenticator (Optional for EKS)

3)Authenticate with AWS EKS Cluster
```
aws eks update-kubeconfig --name your-eks-cluster-name --region your-aws-region
```
Replace your-eks-cluster-name with the name of your EKS cluster and your-aws-region with the AWS region where your cluster is deployed.

4)Verify Kubeconfig
```
kubectl config view
```
# Deploying the LLM Model "Github Issue Summarization" over Kubeflow

1)Build the Docker Image for the model "Github Issue Summarization"
```
(i)Make sure you have Docker installed on your local machine.
(ii)Create a Dockerfile in the root directory of your project. The Dockerfile defines the environment and steps to build the Docker image.
(iii)Open a terminal or command prompt and navigate to the directory containing the Dockerfile and your project files.
(iv)Use the docker build command to build the Docker image. The basic syntax is as follows:
    docker build -t <image_name>:<tag> .
      ->Replace <image_name> with the desired name for your Docker image.
      ->Replace <tag> with a tag for the image (e.g., latest, v1.0, etc.).
      ->The period . at the end of the command specifies that the build context is the current directory (where the Dockerfile and project files are located). Make         sure to include the period at the end of the command.
```
2)Push the docker image in local to docker hub

3)Make a terraform file named "eks_github_issue_summarization.tf" in the same directory as the "main.tf" after provisioning the Kubernetes Cluster and Kubeflow on   EKS.
```


# provider "kubernetes" {
#   config_path = "~/.kube/config"  # Path to your kubectl config file
# }

resource "kubernetes_namespace" "github_summarization" {
  
  metadata {
    name = "github-summarization"  # Change to your desired namespace name
  }
}

# locals {
#   dockerhub_credentials = jsonencode({
#     auths = {
#       "https://index.docker.io/v1/" = {
#         auth = base64encode("aayush2310:Aayush@2096")
#       }
#     }
#   })
# }

# resource "kubernetes_secret" "dockerhub_credentials" {
#   metadata {
#     name      = "dockerhub-credentials"
#     namespace = kubernetes_namespace.github_summarization.metadata[0].name  # Change this to the desired namespace
#   }

#   data = {
#     "dockerconfigjson" = local.dockerhub_credentials
#   }
# }



# resource "kubernetes_service_account" "dockerhub_service_account" {
#   metadata {
#     name      = "dockerhub-sa"
#     namespace = kubernetes_namespace.github_summarization.metadata[0].name  # Change this to the desired namespace
#   }

#   image_pull_secret {
#     name = kubernetes_secret.dockerhub_credentials.metadata[0].name
#   }
# }

resource "kubernetes_secret" "dockerhub_credentials" {
  metadata {
    name      = "dockerhub-credentials"
    namespace = kubernetes_namespace.github_summarization.metadata[0].name  # Change this to the desired namespace
  }

  data = {
    "dockerconfigjson" = jsonencode({
      auths = {
        "https://index.docker.io/v1/" = {
          auth = base64encode("aayush2310:Aayush@2096")
        }
      }
    })
  }
}


resource "kubernetes_deployment" "github_summarization" {
  metadata {
    name      = "github-summarization"
    namespace = kubernetes_namespace.github_summarization.metadata[0].name
    labels = {
      app = "github-summarization"
    }
  }

  spec {
    replicas = 1

    selector {
      match_labels = {
        app = "github-summarization"
      }
    }

    template {
      metadata {
        labels = {
          app = "github-summarization"
        }
      }

      spec {
        //service_account_name = kubernetes_service_account.dockerhub_service_account.metadata[0].name

        container {
          image = "docker.io/aayush2310/github-issue-summarization:latest"  # Replace with your actual image details
          name  = "github-summarization"
        }
      }
    }
  }
}

resource "kubernetes_service" "github_summarization" {
  metadata {
    name      = "github-summarization"
    namespace = kubernetes_namespace.github_summarization.metadata[0].name
  }

  spec {
    selector = {
      app = "github-summarization"
    }

    port {
      port        = 80
      target_port = 80
    }
  }
}
```
4)Terraform init -> Terraform plan -> Terraform apply

![IMG-1](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/Screenshot%201402-05-14%20at%2011.47.29.png)
![IMG-2](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/Screenshot%201402-05-14%20at%2011.48.12.png)
![IMG-3](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/Screenshot%201402-05-14%20at%2012.02.34.png)
![IMG-4](https://github.ibm.com/aayushjha2310/Modelling-the-Hybrid-Distributed-Multi-Cloud-/blob/main/Deploying-Kubeflow-over-the-existing-Kubernetes-Cluster/Screenshot%201402-05-14%20at%2012.02.38.png)
